
DROP INDEX idx_auditoria_competencia;
DROP INDEX idx_centro_custo_itens_competencia;
DROP INDEX idx_previsao_itens_competencia;
DROP INDEX idx_competencias_mes_ano;
DROP TABLE auditoria_previsao;
DROP TABLE centro_custo_itens;
DROP TABLE centros_custo;
DROP TABLE previsao_itens;
DROP TABLE competencias;
